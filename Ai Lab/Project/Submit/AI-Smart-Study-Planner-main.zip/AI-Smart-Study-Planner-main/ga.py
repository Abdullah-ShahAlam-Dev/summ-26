"""
  - Day runs 08:00 → 24:00 (midnight), max 16 usable hours
  - Morning window : 08:00 16:00  (slots 8-9 … 15-16)
  - Evening window : 16:00 4:00  (slots 16-17 … 23-24)
  - If all subjects prefer Morning, morning slots fill first (8→16),
    overflow goes into evening.  Same logic applies in reverse.
  - Schedule NEVER goes past 24:00.
"""

import random
from copy import deepcopy
from collections import Counter
from fitness import calculate_fitness, sort_schedule_by_priority

DAY_START      = 8  
DAY_END        = 24  
MAX_DAY_SLOTS  = DAY_END - DAY_START  
MORNING_END    = 16   
EVENING_START  = 16  

def all_day_slots():
    return [f"{h}-{h+1}" for h in range(DAY_START, DAY_END)]


def morning_slots():
    return [f"{h}-{h+1}" for h in range(DAY_START, MORNING_END)]   # 8 slots


def evening_slots():
    return [f"{h}-{h+1}" for h in range(EVENING_START, DAY_END)]   # 8 slots


def build_ordered_slots(subjects_data, preferred_times, break_interval):
   
    total_study  = sum(s["hours"] for s in subjects_data)
    n_breaks     = total_study // break_interval
    total_needed = min(total_study + n_breaks, MAX_DAY_SLOTS)

    all_evening = all(
        preferred_times.get(s["name"], "Morning") == "Evening"
        for s in subjects_data
    )

    slot_pool = evening_slots() + morning_slots() if all_evening else morning_slots() + evening_slots()
    return slot_pool[:total_needed]


def get_overflow_subjects(subjects_data, break_interval):
    total_study  = sum(s["hours"] for s in subjects_data)
    n_breaks     = total_study // break_interval
    if total_study + n_breaks <= MAX_DAY_SLOTS:
        return []

    avail_study = (MAX_DAY_SLOTS * break_interval) // (break_interval + 1)

    sorted_subs = sorted(subjects_data, key=lambda s: s.get("priority", 1), reverse=True)
    used = 0
    overflow = []
    for s in sorted_subs:
        if used + s["hours"] <= avail_study:
            used += s["hours"]
        else:
            cut = s["hours"] - max(0, avail_study - used)
            used = avail_study
            if cut > 0:
                overflow.append(f"{s['name']} ({cut}h → continue next day)")
    return overflow



def balance_sequence(seq, subjects_data):
    target  = {s["name"]: s["hours"] for s in subjects_data}
    seq     = [s for s in seq if s != "Break"]
    current = Counter(seq)

    for i in range(len(seq)):
        sub = seq[i]
        if current.get(sub, 0) > target.get(sub, 0):
            for need_sub, need_count in target.items():
                if current.get(need_sub, 0) < need_count:
                    current[sub]    -= 1
                    current[need_sub] = current.get(need_sub, 0) + 1
                    seq[i]          = need_sub
                    break

    result    = []
    remaining = dict(target)
    for sub in seq:
        if remaining.get(sub, 0) > 0:
            result.append(sub)
            remaining[sub] -= 1
    for sub, cnt in remaining.items():
        result.extend([sub] * cnt)

    return result


def fix_consecutive(seq):
    seq = list(seq)
    for i in range(1, len(seq)):
        if seq[i] == seq[i - 1]:
            for j in range(i + 1, len(seq)):
                if seq[j] != seq[i]:
                    seq[i], seq[j] = seq[j], seq[i]
                    break
    return seq


def inject_breaks(seq, break_interval):
    result, count = [], 0
    for sub in seq:
        result.append(sub)
        count += 1
        if count >= break_interval:
            result.append("Break")
            count = 0
    return result


def assign_slots(subject_seq, ordered_slots):
    n = len(ordered_slots)
    subj = subject_seq[:n]
    while len(subj) < n:
        subj.append("Break")
    return list(zip(ordered_slots, subj))



def make_schedule(subjects_data, preferred_times, break_interval):
    pool = []
    for s in subjects_data:
        pool.extend([s["name"]] * s["hours"])
    random.shuffle(pool)
    pool  = fix_consecutive(pool)
    seq   = inject_breaks(pool, break_interval)
    slots = build_ordered_slots(subjects_data, preferred_times, break_interval)
    return assign_slots(seq, slots)



def initialize_population(size, subjects_data, preferred_times, break_interval):
    return [make_schedule(subjects_data, preferred_times, break_interval)
            for _ in range(size)]


def tournament_selection(population, fitness_scores, k=3):
    indices = random.sample(range(len(population)), min(k, len(population)))
    return deepcopy(population[max(indices, key=lambda i: fitness_scores[i])])


def crossover(p1, p2, subjects_data, preferred_times, break_interval):
    s1 = [sub for _, sub in p1 if sub != "Break"]
    s2 = [sub for _, sub in p2 if sub != "Break"]
    n  = len(s1)
    if n < 2:
        return make_schedule(subjects_data, preferred_times, break_interval)
    mid         = random.randint(1, n - 1)
    child_study = (s1[:mid] + s2[mid:])[:n]
    child_study = balance_sequence(child_study, subjects_data)
    child_study = fix_consecutive(child_study)
    seq         = inject_breaks(child_study, break_interval)
    slots       = build_ordered_slots(subjects_data, preferred_times, break_interval)
    return assign_slots(seq, slots)


def mutate(schedule, mutation_rate, subjects_data, preferred_times, break_interval):
    study_seq = [sub for _, sub in schedule if sub != "Break"]
    subjects  = [s["name"] for s in subjects_data]
    mutated   = list(study_seq)
    for i in range(len(mutated)):
        if random.random() < mutation_rate:
            if random.random() < 0.5:          # swap
                j = random.randint(0, len(mutated) - 1)
                mutated[i], mutated[j] = mutated[j], mutated[i]
            else:                               # replace
                mutated[i] = random.choice(subjects)
    mutated = balance_sequence(mutated, subjects_data)
    mutated = fix_consecutive(mutated)
    seq     = inject_breaks(mutated, break_interval)
    slots   = build_ordered_slots(subjects_data, preferred_times, break_interval)
    return assign_slots(seq, slots)



def run_ga(
    subjects_data,
    preferred_times,
    total_hours,
    break_interval=2,
    population_size=30,
    generations=50,
    base_mutation_rate=0.1,
    progress_callback=None,
):
    
    total_study = sum(s["hours"] for s in subjects_data)
    n_breaks    = total_study // break_interval
    total_slots_needed = total_study + n_breaks
    if total_slots_needed > MAX_DAY_SLOTS:
        pass

    population = initialize_population(
        population_size, subjects_data, preferred_times, break_interval
    )

    fitness_history = []
    best_schedule   = None
    best_fitness    = float("-inf")
    mutation_rate   = base_mutation_rate
    stagnation      = 0

    for gen in range(generations):
        fitness_scores = [
            calculate_fitness(chrom, subjects_data, preferred_times)
            for chrom in population
        ]

        gen_best_idx     = max(range(len(population)), key=lambda i: fitness_scores[i])
        gen_best_fitness = fitness_scores[gen_best_idx]
        fitness_history.append(gen_best_fitness)

        if gen_best_fitness > best_fitness:
            best_fitness  = gen_best_fitness
            best_schedule = deepcopy(population[gen_best_idx])
            stagnation    = 0
        else:
            stagnation += 1

        if stagnation >= 5:
            mutation_rate = min(0.5, mutation_rate + 0.05)
        else:
            mutation_rate = max(base_mutation_rate, mutation_rate - 0.01)

        if progress_callback:
            progress_callback(gen + 1, gen_best_fitness)

        sorted_idx     = sorted(range(len(population)),
                                key=lambda i: fitness_scores[i], reverse=True)
        new_population = [deepcopy(population[i]) for i in sorted_idx[:2]]

        while len(new_population) < population_size:
            p1    = tournament_selection(population, fitness_scores)
            p2    = tournament_selection(population, fitness_scores)
            child = crossover(p1, p2, subjects_data, preferred_times, break_interval)
            child = mutate(child, mutation_rate, subjects_data,
                           preferred_times, break_interval)
            new_population.append(child)

        population = new_population

    best_schedule = sort_schedule_by_priority(best_schedule, subjects_data)
    best_fitness  = calculate_fitness(best_schedule, subjects_data, preferred_times)

    overflow = get_overflow_subjects(subjects_data, break_interval)
    return best_schedule, best_fitness, fitness_history, overflow